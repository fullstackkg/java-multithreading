//Name: Khalil Gayle    Student Number: 301170285

public enum TransactionType {

    DEPOSIT,
    WITHDRAW;

}
